<?php $__env->startSection('content'); ?>
 <div class="centered">
 	<a href="<?php echo e(route('niceaction',['action'=>'greet'])); ?>">Greet</a>
 	<a href="<?php echo e(route('niceaction',['action'=>'hug'])); ?>">Hug</a>
 	<a href="<?php echo e(route('niceaction',['action'=>'kiss'])); ?>">Kiss</a>
 	<br><br>
 	<form method="post" action="<?php echo e(route('benice')); ?>">
 		<label>I Want to be...</label>
 		<select id="select-action" name="action">
 			<option value="greet">Greet</option>
 			<option value="hug">Hug</option>
 			<option value="kiss">Kiss</option>
 		</select>
 		<input type="text" name="name" value="" placeholder="">
 		<button type="submit" name="" value="submit">Do a nice action!</button>
 		<input type="hidden" name="" value="<?php echo e(Session::token()); ?>" name="_token">
 	</form>
 </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>