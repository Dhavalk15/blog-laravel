<h1>We received your message!</h1>
<p>Thank you,we will respond as soon as possible.</p>
<h3>Information about your message</h3>

<p>Subject: <?php echo e($contact_message->subject); ?> </p>