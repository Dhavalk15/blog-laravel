<!DOCTYPE html>
<html>
    <head>
        <title>Laravel</title>

        <link href="https://fonts.googleapis.com/css?family=Lato:100" rel="stylesheet" type="text/css">

        <style>
            
        </style>
    </head>
    <body>
        <h1>Hey This is My First Laravel App</h1>
        <p>Let's create something better</p>
    </body>
</html>
