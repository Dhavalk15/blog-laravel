<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="<?php echo e(URL::to('src/css/modal.css')); ?>">


<?php $__env->startSection('content'); ?>
<div class="container">
	<?php echo $__env->make('includes.info-box', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<div class="card">
		<header>
			<nav>
				<ul>
					<li><a href="<?php echo e(route('admin.blog.create_post')); ?>" class="btn">New Post</a></li>
					<li><a href="<?php echo e(route('admin.blog.index')); ?>" class="btn">Show All</a></li>
				</ul>
			</nav>
		</header>
		<section>
			<ul>
				<!-- If no post -->
				<?php if(count($posts) == 0): ?>
				<li>No Post</li>

				<?php else: ?>

					<?php foreach($posts as $post): ?>
					<li>
						<article>
							<div class="post-info">
								<h3><?php echo e($post->title); ?></h3>
								<span class="info"><?php echo e($post->author); ?> | <?php echo e($post->created_at->toFormattedDateString()); ?></span>
							</div>
							<div class="edit">
								<nav>
									<ul>
										<li><a href="<?php echo e(route('admin.blog.post', ['post_id'=>$post->id, 'end'=>'admin'])); ?>">View Post</a></li>
										<li><a href="<?php echo e(route('admin.blog.post.edit', ['post_id'=>$post->id])); ?>">Edit</a></li>
										<li><a href="<?php echo e(route('admin.blog.post.delete', ['post_id'=>$post->id])); ?>" class="danger">Delete</a></li>
									</ul>
								</nav>
							</div>
						</article>
					</li>

					<?php endforeach; ?>

				<?php endif; ?>
			</ul>
		</section>
	</div>

	<div class="card">
		<header>
			<nav>
				<ul>
					<li><a href="<?php echo e(route('admin.contact.index')); ?>" class="btn">Show All Messages</a></li>
				</ul>
			</nav>
		</header>
		<section>
			<ul>
				<!-- If no post -->
				<?php if(count($contact_messages) == 0): ?>
				<li>No Messages</li>
				
				<?php else: ?>
					<?php foreach($contact_messages as $contact_message): ?>
					<li>
						<article data-message="<?php echo e($contact_message->message); ?>" data-id="<?php echo e($contact_message->id); ?>">
							<div class="message-info">
								<h3><?php echo e($contact_message->subject); ?></h3>
								<span class="info"><?php echo e($contact_message->sender); ?> | <?php echo e($contact_message->created_at); ?></span>
							</div>
							<div class="edit">
								<nav>
									<ul>
										<li><a href="">Show Message</a></li>
										<li><a href="" class="danger">Delete</a></li>
									</ul>
								</nav>
							</div>
						</article>
					</li>
					<?php endforeach; ?>
				<?php endif; ?>
			</ul>
		</section>
	</div>
</div>

<div class="modal" id="contact-message-info">
	<button class="btn" id="modal-close">Close</button>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
	<script type="text/javascript">
		var token = "<?php echo e(Session::token()); ?>";
	</script>
	<script type="text/javascript" src="<?php echo e(URL::to('src/js/modal.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(URL::to('src/js/contact_messages.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>