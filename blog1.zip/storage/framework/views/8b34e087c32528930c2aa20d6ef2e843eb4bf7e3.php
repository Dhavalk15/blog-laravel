<header>
	<nav class="main-nav">
		<ul>
         <li><a href="<?php echo e(route('blog.index')); ?>">Blog</a></li>
         <li><a href="<?php echo e(route('about')); ?>">About me</a></li>
         <li><a href="<?php echo e(route('contact')); ?>">Contact</a></li>
		</ul>
	</nav>
</header>